<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class add_brand extends Model
{
    //
    protected $fillable=['brand_name','brand_description','long_description'];
}
