<?php $__env->startSection('body'); ?>
<div class="row">
    <div  class="col-md-10 col-md-offset-1">
        <div class="panel panel-default">
                <h3 class="text-center text-success"></h3>
            <h3><?php echo e(Session::get('message')); ?></h3>

                             <form method="POST" action="<?php echo e(route('new_product')); ?>" enctype="multipart/form-data">
                                 <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="control-label col-md-3">Category Name</label>
                    <div class="col-md-9">
                        <select class="form-control" name="category_name">
                            <option>---Select a Name</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3">Brand Name</label>
                    <div class="col-md-9">
                        <select class="form-control" name="brand_name">
                            <option>---Select a Name</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3">product Name</label>
                    <div class="col-md-9">
                        <input type="text" name="product_name" class="form-control"/>

                    </div>
                </div>


                <div class="form-group">
                    <label class="control-label col-md-3">product Price</label>
                    <div class="col-md-9">
                        <input type="number" name="product_price" class="form-control"/>

                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3">product Quantity</label>
                    <div class="col-md-9">
                        <input type="number" name="product_quantity" class="form-control"/>

                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3">Product Description</label>
                    <div class="col-md-9">
                        <input type="text" name="product_description" class="form-control"/>

                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-3">long Description</label>
                    <div class="col-md-9">
                        <textarea class="form-control" name="long_description"></textarea>

                    </div>
                </div>


                <div class="form-group">
                    <label class="control-label col-md-3">product image</label>
                    <div class="col-md-9">
                        <input type="file" name="product_image" accept="image/*">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-md-9">
                        <input type="submit" name="btn" value="Save product Info">

                    </div>
                </div>
            </form>

        </div>
    </div>
</div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xammpp\htdocs\first_blog\resources\views/product/add_product.blade.php ENDPATH**/ ?>